from django.contrib import admin
from .models import Employee, Timesheet

class EmployeeAdmin(admin.ModelAdmin):
    list_display = ('emp_id', 'emp_name', 'email_id')
    search_fields = ('emp_id', 'emp_name', 'email_id')

class TimesheetAdmin(admin.ModelAdmin):
    list_display = ('emp', 'date', 'project_name', 'start_time', 'end_time', 'total_hours','lead_approval','manager_approval')
    list_filter = ('date', 'project_name', 'emp')
    search_fields = ('project_name', 'emp__emp_name', 'emp__emp_id')

admin.site.register(Employee, EmployeeAdmin)
admin.site.register(Timesheet, TimesheetAdmin)
