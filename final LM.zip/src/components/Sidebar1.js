// src/Sidebar1.js
import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faClock, faHome, faFileAlt, faChartBar, faTasks, faStar, faUsers, faDollarSign, faCogs } from '@fortawesome/free-solid-svg-icons';
import './Sidebar1.css';
import { Link } from 'react-router-dom';
const Sidebar1 = ({ onCalendarClick }) => {
  return (
    <div className="sidebar">
      <div className="sidebar-title">
        <FontAwesomeIcon icon={faClock} />
        <span>Dashboard</span>
      </div>
      <div className="sidebar-search">
        <input type="text" placeholder="Search..." />
      </div>
      <div className="sidebar-menu">
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faHome} />
          <span><Link to="/manager-dashboard" className="sidebar-link">Home Page</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faFileAlt} />
          <span>All Pages</span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faChartBar} />
          <span>Reports</span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faTasks} />
          <span><Link to="/calendar" className="sidebar-link">Task</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faStar} />
          <span><Link to="/teamtable" className="sidebar-link">Features</Link></span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faUsers} />
          <span><Link to="/employees" className="sidebar-link">Users</Link></span>
            
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faDollarSign} />
          <span>Pricing</span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faCogs} />
          <span>Integrations</span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faCogs} />
          <span>Setting</span>
        </div>
        <div className="sidebar-item">
          <FontAwesomeIcon icon={faFileAlt} />
          <span>Template Pages</span>
        </div>
      </div>
      
    </div>
  );
};
export default Sidebar1;