// src/App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Dashboard from './components/Dashboard';
import EmployeeDetail from './components/EmployeeDetail';
import EmployeeTimesheet from './components/EmployeeTimesheet';
import Login from './components/Login';
import EmployeeDashboard from './components/EmployeeDashboard';
import ManagerDashboard from './components/ManagerDashboard';
import Sidebar from './components/Sidebar';
import Sidebar1 from './components/Sidebar1';
import './App.css'

function App() {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
    const [personstatus, setPersonstatus] = useState('');

    
    
    
    return (
        <Router>
            {!isLoggedIn ? (
                <Routes>
                   // <Route exact path="/" element={<Login onLogin={(handleLogin) => setIsLoggedIn(true)} />} />
                   // <Route exact path="/login" element={<Login onLogin={(handleLogin) => setIsLoggedIn(true)} />} />
                </Routes>
            ) : (
                <>
                    {personstatus === 'Lead' ? <Sidebar /> : <Sidebar1 /> }
                    
                    <Routes>
                    <Route exact path="/" element={<Dashboard />} />
                        <Route exact path="/lead-dashboard" element={<Dashboard />} />
                        <Route exact path="/employee/:emp_id" element={<EmployeeDetail />} />
                        <Route exact path="/timesheet/:emp_id" element={<EmployeeTimesheet />} />
                        <Route exact path="/employee-dashboard" element={<EmployeeDashboard />} />
                        <Route exact path="/manager-dashboard" element={<ManagerDashboard />} />
                       
                    </Routes>
                    
                  
                </>
                
            )}
        </Router>
    );
}

export default App;
