// src/components/ManagerSheetForm.js

import React, { useState } from 'react';
import axios from 'axios';
import './ManagerSheetForm.css'; // Import the CSS file

const ManagerSheetForm = () => {
  const [projectName, setProjectName] = useState('');
  const [deadLine, setDeadLine] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await axios.post('http://127.0.0.1:8000/api/manager/', {
        project_name: projectName,
        dead_line: deadLine,
      });
      setProjectName('');
      setDeadLine('');
      setError('');
      alert('Data submitted successfully!');
    } catch (err) {
      setError('Error submitting data');
      console.error(err);
    }
  };

  return (
    <div className="form-container">
      <h2>Project assigning</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="projectName">Project Name:</label>
          <input
            type="text"
            id="projectName"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            required
          />
        </div>
        <div>
          <label htmlFor="deadLine">Deadline:</label>
          <input
            type="date"
            id="deadLine"
            value={deadLine}
            onChange={(e) => setDeadLine(e.target.value)}
            required
          />
        </div>
        <button type="submit">Submit</button>
        {error && <p>{error}</p>}
      </form>
    </div>
  );
};

export default ManagerSheetForm;
