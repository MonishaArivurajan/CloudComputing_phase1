import React, { useState } from 'react';
import './CalculateSalary.css';
const CalculateSalary = () => {
    const [userId, setUserId] = useState('');
    const [salary, setSalary] = useState(null);
    const [error, setError] = useState(null);
    const [loading, setLoading] = useState(false);
    const [workingHours, setWorkingHours] = useState(null);
    const [leaveDays, setLeaveDays] = useState(null);

    const handleInputChange = (event) => {
        setUserId(event.target.value);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        setLoading(true);
        setWorkingHours(null);
        setLeaveDays(null);
        setError(null);
        setSalary(null);

        try {
            const response = await fetch(`http://127.0.0.1:8000/api/timesheet/calculate-salary/${userId}/`);
            const data = await response.json();
            console.log(data);
            if (response.ok) {
                setSalary(data.total_salary);
                setWorkingHours(data.total_working_hours);
                setLeaveDays(data.Leave_days);
            } else {
                setError(data.error || 'An error occurred');
            }
        } catch (error) {
            setError('An error occurred while calculating the salary.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <div style={styles.container}>
            <h2>Calculate Employee Salary</h2>
            <form onSubmit={handleSubmit} style={styles.form}>
                <label htmlFor="user-id">User ID:</label>
                <input
                    type="text"
                    id="user-id"
                    value={userId}
                    onChange={handleInputChange}
                    style={styles.input}
                    required
                />
                
                <button type="submit" style={styles.button} disabled={loading}>
                    {loading ? 'Calculating...' : 'Calculate Salary'}
                </button>
            </form>
            {error && <div style={styles.error}>{error}</div>}
            {salary !== null && !error && (
                <div style={styles.result}>
                  <center>
                    <p><b>Working Hours of {userId}:{workingHours}</b></p>
                    <p><b>Number of Leave Days:{leaveDays}</b></p>
                    <p><b>Total Salary for User ID {userId}: ₹{salary}</b></p>
                  </center> 
                    
                </div>
            )}
        </div>
    );
};

const styles = {
    container: {
        fontFamily: 'Arial, sans-serif',
        backgroundColor: '#f4f4f4',
        padding: '20px',
        borderRadius: '8px',
        boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)',
        textAlign: 'center',
        width: '400px',
        margin: '0% auto',
        height:'100%',
    },
    form: {
        
        marginBottom: '20px',
    },
    input: {
        padding: '10px',
        marginRight: '10px',
        width: '200px',
        borderRadius: '4px',
        border: '1px solid #ccc',
    },
    button: {
        padding: '10px 20px',
        backgroundColor:'#0F1035',
        color: 'white',
        border: 'none',
        borderRadius: '4px',
        cursor: 'pointer',
    },
    buttonDisabled: {
        backgroundColor: '#0056b3',
    },
    result: {
        marginTop: '20px',
        fontSize: '1.2em',
        color: '#333',
        
    },
    error: {
        marginTop: '20px',
        color: 'red',
    },
    p:{
      
    },
};

export default CalculateSalary;