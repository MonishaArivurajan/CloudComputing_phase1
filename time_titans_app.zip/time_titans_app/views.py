from django.shortcuts import render
from rest_framework import status,viewsets
from rest_framework import generics, status
from rest_framework.response import Response
from rest_framework.permissions import AllowAny, IsAuthenticated
from .models import User, EmployeeDetail
from rest_framework.decorators import action
from .serializers import RegisterSerializer, EmployeeDetailSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.decorators import api_view, permission_classes
from rest_framework.views import APIView
from rest_framework import status


class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = (AllowAny,)
    serializer_class = RegisterSerializer


    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response({"message": "You have successfully registered"}, status=status.HTTP_201_CREATED)


class EmployeeDetailView(generics.ListCreateAPIView):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer
    permission_classes = (AllowAny,)


class EmployeeDetailByEmpIDView(generics.RetrieveAPIView):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer
    permission_classes = (AllowAny,)
    lookup_field = 'emp_id'


class EmployeeDetailsView(APIView):
    def get(self, request):
        # Implement your logic here
        return Response({"message": "Employee details"}, status=status.HTTP_200_OK)


    def post(self, request):
        # Implement your logic here
        return Response({"message": "Employee details saved"}, status=status.HTTP_201_CREATED)


class TimeSheetViewSet(viewsets.ModelViewSet):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer
    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.lead_approval = 'Approved'
        timesheet.save()
        return Response({'status': 'Timesheet approved by Lead'}, status=status.HTTP_200_OK)
    
    
    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.lead_approval = 'Rejected'
        timesheet.save()
        return Response({'status': 'Timesheet rejected by Lead'}, status=status.HTTP_200_OK)
    
    
    @action(detail=True, methods=['post'])
    def manager_approve(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.manager_approval = 'Approved'
        timesheet.save()
        return Response({'status': 'Timesheet approved by Manager'}, status=status.HTTP_200_OK)
    
    
    @action(detail=True, methods=['post'])
    def manager_reject(self, request, pk=None):
        timesheet = self.get_object()
        timesheet.manager_approval = 'Rejected'
        timesheet.save()
        return Response({'status': 'Timesheet rejected by Manager'}, status=status.HTTP_200_OK)
