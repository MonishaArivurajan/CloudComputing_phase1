   
# models.py
from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

class UserManager(BaseUserManager):
    def create_user(self, email, name,emp_id,phone_number, password=None):
        if not email:
            raise ValueError('The Email field must be set')
        user = self.model(
            email=self.normalize_email(email),
            name=name,
            emp_id=emp_id,
            phone_number=phone_number
        )
        user.set_password(password)
        user.save(using=self._db)
        return user
    
    def create_superuser(self, email,emp_id, name, phone_number, password=None):
        user = self.create_user(
            email=email,
            name=name,
            emp_id=emp_id,
            password=password,
            phone_number=phone_number,
        )
        user.is_admin = True
        user.save(using=self._db)
        return user
    
class User(AbstractBaseUser):
    email = models.EmailField(max_length=255, unique=True)
    emp_id = models.CharField(max_length=10, unique=True)
    name = models.CharField(max_length=30)
    phone_number = models.CharField(max_length=15)
    personstatus = models.CharField(max_length=10, choices=[('Employee', 'Employee'),('Lead', 'Lead'),('Manager', 'Manager')])   
    is_active = models.BooleanField(default=True)
    is_admin = models.BooleanField(default=False)
    objects = UserManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['emp_id','name', 'phone_number']
    
    def __str__(self):
        return self.emp_id

class EmployeeDetail(models.Model):
    employee = models.ForeignKey(User, on_delete=models.CASCADE)
    date = models.DateField()
    comments = models.TextField()
    lead_approval = models.CharField(max_length=20, choices=[('approved', 'Approved'), ('rejected', 'Rejected'), ('pending', 'Pending')])
    manager_approval=models.CharField(max_length=20,choices=[('approved','Approved'),('rejected', 'Rejected'),('pending', 'Pending')])

class TimeSheet(models.Model):
    employee = models.ForeignKey(User, on_delete=models.CASCADE)
    employee_name = models.CharField(max_length=100)
    emp_id = models.CharField(max_length=10)
    start_time = models.DateTimeField()
    nd_time = models.DateTimeField()
    project_name = models.CharField(max_length=100)
    total_hours_worked = models.DecimalField(max_digits=5, decimal_places=2)
    lead_approval = models.CharField(max_length=20, choices=[('Approved', 'Approved'), ('Rejected', 'Rejected'), ('Pending', 'Pending')])
    manager_approval = models.CharField(max_length=20, choices=[('Approved', 'Approved'), ('Rejected', 'Rejected'), ('Pending', 'Pending')])

    def __str__(self):
        return self.employee_name

   

