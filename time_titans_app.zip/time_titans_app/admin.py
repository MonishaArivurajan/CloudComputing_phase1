from django.contrib import admin
from .models import User, EmployeeDetail


admin.site.register(User)
admin.site.register(EmployeeDetail)





