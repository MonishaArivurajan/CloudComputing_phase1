from django.contrib import admin

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import Group
from .models import User, EmployeeDetail

class UserAdmin(BaseUserAdmin):
    list_display = ('username', 'email', 'emp_id', 'is_admin')
    list_filter = ('is_admin',)
    fieldsets = (
        (None, {'fields': ('username', 'email', 'emp_id', 'password')}),
        ('Permissions', {'fields': ('is_admin',)}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'email', 'emp_id', 'password1', 'password2'),
        }),
    )
    search_fields = ('username', 'email', 'emp_id')
    ordering = ('username', 'email')
    filter_horizontal = ()

class EmployeeDetailAdmin(admin.ModelAdmin):
    list_display = ('emp_id', 'employee_name', 'date', 'project_name', 'total_hours_worked', 'lead_approval', 'manager_approval')
    search_fields = ('employee_name', 'project_name')
    list_filter = ('lead_approval', 'manager_approval', 'date')

# Register your models here.
admin.site.register(User, UserAdmin)
admin.site.register(EmployeeDetail, EmployeeDetailAdmin)

# Unregister the Group model from admin as we are not using it
admin.site.unregister(Group)
