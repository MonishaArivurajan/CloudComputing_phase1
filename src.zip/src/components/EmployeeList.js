import React, { useState, useEffect } from 'react';
import axios from 'axios';

const EmployeeList = ({ onSelectEmployee }) => {
  const [employees, setEmployees] = useState([]);
  const [searchTerm, setSearchTerm] = useState(''); // State to hold the search term

  useEffect(() => {
    // Fetch the employee list from the API
    axios.get('http://127.0.0.1:8000/api/employee-details/')
      .then(response => {
        console.log('Employee data:', response.data); // Check the data
        setEmployees(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the employee list!', error);
      });
  }, []);

  // Filter employees based on the search term
  const filteredEmployees = employees.filter(employee =>
    employee.employee_name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div>
      <h1>Employee List</h1>
      <input
        type="text"
        placeholder="Search by name"
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)} // Update the search term
        style={{ marginBottom: '10px', padding: '5px', width: '100%' }}
      />
      <ul>
        {filteredEmployees.map(employee => (
          <li
            key={employee.emp_id} // Use emp_id as the key
            onClick={() => onSelectEmployee(employee.emp_id)}
            style={{ cursor: 'pointer', margin: '5px', padding: '5px', border: '1px solid #ddd' }}
          >
            {employee.employee_name}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default EmployeeList;
