import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './TeamTable.css';

const getStatusColor = (status) => {
    switch(status) {
        case 'approved':
            return 'green';
        case 'rejected':
            return 'red';
        case 'pending':
            return 'yellow';
        default:
            return 'white';
    }
};

const TeamTable = () => {
    const [search, setSearch] = useState('');
    const [data, setData] = useState([]);
    
    useEffect(() => {
        // Fetch data from the API
        axios.get('http://127.0.0.1:8000/api/employee-details/')
            .then(response => {
                setData(response.data);
            })
            .catch(error => {
                console.error('There was an error fetching the employee data!', error);
            });
    }, []);

    const handleStatusChange = (employeeId, newStatus) => {
        setData(prevData => 
            prevData.map(item =>
                item.emp_id === employeeId ? { ...item, lead_approval: newStatus } : item
            )
        );
    };

    const filteredData = data.filter(item =>
        item.employee_name.toLowerCase().includes(search.toLowerCase()) ||
        item.emp_id.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="table-container">
            <input
                type="text"
                placeholder="Search by name or ID..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="search-input"
            />
            <table className="table">
                <thead>
                    <tr>
                        <th>EmpID</th>
                        <th>Name</th>
                        <th>InTime</th>
                        <th>OutTime</th>
                        <th>Date</th>
                        <th>Project</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredData.map((row, index) => (
                        <tr key={index}>
                            <td>{row.emp_id}</td>
                            <td>{row.employee_name}</td>
                            <td>{row.start_time}</td>
                            <td>{row.end_time}</td>
                            <td>{row.date}</td>
                            <td>{row.project_name}</td>
                            <td style={{ backgroundColor: getStatusColor(row.lead_approval) }}>
                              {row.lead_approval || ''}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default TeamTable;
