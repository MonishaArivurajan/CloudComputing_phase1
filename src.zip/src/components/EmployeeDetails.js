import React, {useState, useEffect } from 'react';
import axios from 'axios';
const EmployeeDetails = ({ employeeId }) => {
  const [employeeDetails, setEmployeeDetails] = useState([]);
  useEffect(() => {
    if (employeeId) { // Check if employeeId is provided
      // Fetch the employee details from the API
      axios.get(`http://127.0.0.1:8000/api/employee-details/${employeeId}`)
        .then(response => {
            console.log('Employee data:', response.data);
          setEmployeeDetails(response.data);
        })
        .catch(error => {
          console.error('There was an error fetching the employee details!', error);
        });
    }
  }, [employeeId]);
  if (!employeeDetails) {
    return <div>Loading...</div>;
  }
  return (
    <div>
      <h2>Employee Details</h2>
      <p><strong>Name:</strong> {employeeDetails.employee_name}</p>
      <p><strong>ID:</strong> {employeeDetails.emp_id}</p>
      <p><strong>Date:</strong> {employeeDetails.date}</p>
      <p><strong>Start Time:</strong> {employeeDetails.start_time}</p>
      <p><strong>End Time:</strong> {employeeDetails.end_time}</p>
      <p><strong>Project Name:</strong> {employeeDetails.project_name}</p>
      <p><strong>Lead Approval:</strong> {employeeDetails.lead_approval}</p>
    </div>
  );
};
export default EmployeeDetails;