import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import axios from 'axios';
const EmployeeDetail = () => {
    const { emp_id } = useParams();
    const [timesheets, setTimesheets] = useState([]);
    const [employee, setEmployee] = useState(null);
    const [userid, setUserid] = useState('');
    const [personstatus, setPersonstatus] = useState('');
    
    useEffect(() => {
        // Fetch employee details
        const storedUserid = localStorage.getItem('userid');
        const storedPersonstatus = localStorage.getItem('personstatus');


        console.log('Fetched userid:', storedUserid);
        console.log('Fetched personstatus:', storedPersonstatus);

        
        if (storedUserid) {
            setUserid(storedUserid);
        }
        if (storedPersonstatus) {
            setPersonstatus(storedPersonstatus);
        }
        axios.get(`http://127.0.0.1:8000/api/employee/?employee_id=${emp_id}`)
            .then(response => {
                setEmployee(response.data);
            })
            .catch(error => {
                console.error('Error fetching employee details:', error);
            });
        // Fetch timesheets for the employee
        axios.get(`http://127.0.0.1:8000/api/timesheet/?employee=${emp_id}`)
            .then(response => {
                console.log(response.data)
                setTimesheets(response.data);
            })
            .catch(error => {
                console.error('Error fetching timesheets:', error);
            });
        // Fetch person status during login
        axios.get(`http://127.0.0.1:8000/api/user/status/`) // Adjust this endpoint according to your actual API
            .then(response => {
                setPersonstatus(response.data.person_status);
            })
            .catch(error => {
                console.error('Error fetching user status:', error);
            });
    }, [emp_id]);
    // Function to approve a timesheet by lead
    const approveTimesheet = (timesheetId) => {
        axios.post(`http://127.0.0.1:8000/api/timesheet/${timesheetId}/approve/`)
            .then(response => {
                setTimesheets(timesheets.map(timesheet =>
                    timesheet.id === timesheetId ? { ...timesheet, lead_approval: 'Approved' } : timesheet
                ));
            })
            .catch(error => {
                console.error('Error approving timesheet:', error);
            });
    };
    // Function to reject a timesheet by lead
    const rejectTimesheet = (timesheetId) => {
        axios.post(`http://127.0.0.1:8000/api/timesheet/${timesheetId}/reject/`)
            .then(response => {
                setTimesheets(timesheets.map(timesheet =>
                    timesheet.id === timesheetId ? { ...timesheet, lead_approval: 'Rejected' } : timesheet
                ));
            })
            .catch(error => {
                console.error('Error rejecting timesheet:', error);
            });
    };
    // Function to approve a timesheet by manager
    const approveTimesheetByManager = (timesheetId) => {
      axios.post(`http://127.0.0.1:8000/api/timesheet/${timesheetId}/manager_approve/`)
          .then(response => {
              setTimesheets(timesheets.map(timesheet =>
                  timesheet.id === timesheetId ? {...timesheet, manager_approval: 'Approved' }: timesheet
              ));
          })
          .catch(error => {
              console.error('Error approving timesheet by manager:', error);
          });
  };
  
  const rejectTimesheetByManager = (timesheetId) => {
    axios.post(`http://127.0.0.1:8000/api/timesheet/${timesheetId}/manager_reject/`)
        .then(response => {
            setTimesheets(timesheets.map(timesheet =>
                timesheet.id === timesheetId ? {...timesheet, manager_approval: 'Rejected' }: timesheet
            ));
        })
        .catch(error => {
            console.error('Error rejecting timesheet by manager:', error);
        });
};

return (
    <div className="employee-timesheet">
        {personstatus}hello
        <h1>Timesheets for {employee ? employee.name : 'Loading...'}</h1>
        <p>User ID: {userid}</p>
        <p>Person Status: {personstatus}</p>
        <table border="1">
            <thead>
                <tr>
                    <th>Employee Name</th>
                    <th>Emp ID</th>
                    <th>Start Time</th>
                    <th>End Time</th>
                    <th>Project Name</th>
                    <th>Total Worked Hours</th>
                    {personstatus === 'Lead' && <th>Lead Approval</th>}
                    {personstatus === 'Manager' && <th>Manager Approval</th>}
                </tr>
            </thead>
            <tbody>
                
                {timesheets.map(timesheet => (
                    <tr key={timesheet.emp_name}>
                        <td>{timesheet.emp_id}</td>
                        <td>{timesheet.start_time}</td>
                        <td>{timesheet.end_time}</td>
                        <td>{timesheet.project_name}</td>
                        <td>{timesheet.total_hours_worked}</td>
                        <td>{timesheet.lead_approval}</td>
                        
                        
                        {personstatus === 'Lead' && (
                            <td>
                                {timesheet.lead_approval === 'Pending' ? (
                                    <>
                                        <button className="button-group" onClick={() => approveTimesheet(timesheet.id)}>Approve</button>
                                        <button className="button-group" onClick={() => rejectTimesheet(timesheet.id)}>Reject</button>
                                    </>
                                ) : (
                                    timesheet.lead_approval
                                )}
                            </td>
                        )}
                        {personstatus === 'Manager' && (
                            <td>
                                {timesheet.manager_approval === 'Pending' ? (
                                    <>
                                        <button className="button-group" onClick={() => approveTimesheetByManager(timesheet.id)}>Approve</button>
                                        <button className="button-group" onClick={() => rejectTimesheetByManager(timesheet.id)}>Reject</button>
                                    </>
                                ) : (
                                    timesheet.manager_approval
                                )}
                            </td>
                        )}
                    </tr>
                ))}
            </tbody>
        </table>
        <Link to="/lead-dashboard" className="back-link">Back to Dashboard</Link>
    </div>
);
};
export default EmployeeDetail;

