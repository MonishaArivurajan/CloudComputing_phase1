import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const EmployeeDetail = ({ onStatusChange }) => {
  const { id } = useParams(); // Get employeeId from URL params
  const [employeeDetail, setEmployeeDetail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (id) {
      // Fetch the employee details from the API
      axios.get(`http://127.0.0.1:8000/api/employee-details/${id}/`)
        .then(response => {
          console.log('Employee data:', response.data);
          setEmployeeDetail(response.data);
          setLoading(false);
        })
        .catch(error => {
          console.error('There was an error fetching the employee details!', error);
          setError('There was an error fetching the employee details.');
          setLoading(false);
        });
    }
  }, [id]);

  const handleApprovalChange = (employeeId, action) => {
    const endpoint = action === 'approve' 
      ? `http://127.0.0.1:8000/api/employee-details/${employeeId}/update_approval/`
      : `http://127.0.0.1:8000/api/employee-details/${employeeId}/reject/`;

    axios.post(endpoint)
      .then(response => {
        setEmployeeDetail(prevState => ({
          ...prevState,
          lead_approval: action === 'approve' ? 'approved' : 'rejected'
        }));
        onStatusChange(employeeId, action === 'approve' ? 'Approved' : 'Rejected');
      })
      .catch(error => {
        setError('There was an error updating the approval status: ' + error.message);
      });
  };

  if (loading) {
    return <div>Loading...</div>;
  }
  if (error) {
    return <div>{error}</div>;
  }
  
  return (
    <div>
      <h2>Employee Details</h2>
      <table>
        <thead>
          <tr>
            <th>Employee Name</th>
            <th>Emp ID</th>
            <th>Date</th> 
            <th>Start Time</th>
            <th>End Time</th>
            <th>Project Name</th>
            <th>Total Worked Hours</th>
            <th>Lead Approval</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>{employeeDetail.employee_name}</td>
            <td>{employeeDetail.emp_id}</td>
            <td>{employeeDetail.date}</td>
            <td>{employeeDetail.start_time}</td>
            <td>{employeeDetail.end_time}</td>
            <td>{employeeDetail.project_name}</td>
            <td>{employeeDetail.total_hours_worked}</td>
            <td>
              <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'approve')}>Approve</button>
              <button onClick={() => handleApprovalChange(employeeDetail.emp_id, 'reject')}>Reject</button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};

export default EmployeeDetail;
