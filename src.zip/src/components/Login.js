import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './styles.css';
const Login = ({ setToken }) => {
        const [employeeId, setEmployeeId] = useState('');
        const [password, setPassword] = useState('');
        const navigate = useNavigate();
    
        const handleSubmit = async (e) => {
            e.preventDefault();
            try {
                navigate('/dashboard'); // Redirect to dashboard after login
            } catch (error) {
                console.error('Error logging in', error);
            }
        };
    
        return (
            <form onSubmit={handleSubmit}>
                <input type="text" placeholder="Employee ID" value={employeeId} onChange={(e) => setEmployeeId(e.target.value)} required />
                <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
                <button type="submit">Login</button>
            </form>
        );
    };
    
    export default Login;
    