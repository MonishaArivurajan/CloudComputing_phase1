import React, { useState } from 'react';
import './TeamTable.css';

const getStatusColor = (status) => {
    switch(status) {
        case 'approved':
            return 'green';
        case 'rejected':
            return 'red';
        case 'pending':
            return 'yellow';
        default:
            return 'white';
    }
};

const TeamTable = ({ teamData }) => {
    const [search, setSearch] = useState('');

    const filteredData = teamData.filter(item =>
        item.name.toLowerCase().includes(search.toLowerCase()) ||
        item.empid.toLowerCase().includes(search.toLowerCase())
    );

    return (
        <div className="table-container">
            <input
                type="text"
                placeholder="Search by name or ID..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="search-input"
            />
            <table className="table">
                <thead>
                    <tr>
                        <th>EmpID</th>
                        <th>Name</th>
                        <th>InTime</th>
                        <th>OutTime</th>
                        <th>Team</th>
                        <th>Project</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {filteredData.map((row, index) => (
                        <tr key={index}>
                            <td>{row.empid}</td>
                            <td>{row.name}</td>
                            <td>{row.intime}</td>
                            <td>{row.outtime}</td>
                            <td>{row.team}</td>
                            <td>{row.project}</td>
                            <td style={{ backgroundColor: getStatusColor(row.status) }}>{row.status}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default TeamTable;
