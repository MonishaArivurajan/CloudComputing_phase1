import React, { useState } from 'react';
import TeamTable from './components/TeamTable';
import EmployeeDetail from './components/EmployeeDetail';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

const EmployeeDashboard = () => {
  const [data, setData] = useState([]); // State to manage employee data

  const handleStatusChange = (employeeId, newStatus) => {
    setData(prevData => 
      prevData.map(item =>
        item.emp_id === employeeId ? { ...item, lead_approval: newStatus } : item
      )
    );
  };

  return (
    <Router>
      <Switch>
        <Route path="/" exact>
          <TeamTable data={data} />
        </Route>
        <Route path="/employee/:id">
          <EmployeeDetail onStatusChange={handleStatusChange} />
        </Route>
      </Switch>
    </Router>
  );
};

export default EmployeeDashboard;
