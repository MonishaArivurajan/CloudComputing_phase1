import React, { useState } from 'react';
import EmployeeDetail from './EmployeeDetail';
import TeamTable from './TeamTable';

const ParentComponent = () => {
  const [teamData, setTeamData] = useState([
    { empid: 'E001', name: 'John Doe', intime: '09:00', outtime: '17:00', team: 'Team A', project: 'Project X', status: 'approved' },
    { empid: 'E002', name: 'Jane Smith', intime: '10:00', outtime: '18:00', team: 'Team B', project: 'Project Y', status: 'pending' },
    // Add more data as needed
  ]);

  const handleUpdateStatus = (empid, status) => {
    setTeamData(prevData =>
      prevData.map(item =>
        item.empid === empid ? { ...item, status } : item
      )
    );
  };

  return (
    <div>
      <EmployeeDetail onUpdateStatus={handleUpdateStatus} />
      <TeamTable data={teamData} />
    </div>
  );
};

export default ParentComponent;
