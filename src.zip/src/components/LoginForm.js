 // src/components/LoginForm.js
 import React, { useState } from 'react';
 const LoginForm = ({ onLogin }) => {
   const [empid, setEmpid] = useState('');
   const [password, setPassword] = useState('');
   const handleLogin = () => {
     // Add your login logic here
     // After successful login, call the onLogin function with the empid
     onLogin(empid);
   };
   return (
     <div className="login-form">
       <h2>Login</h2>
       <input
         type="text"
         placeholder="empid"
         value={empid}
         onChange={(e) => setEmpid(e.target.value)}
       />
       <input
         type="password"
         placeholder="Password"
         value={password}
         onChange={(e) => setPassword(e.target.value)}
       />
       <button onClick={handleLogin}>Login</button>
     </div>
   );
 };
 export default LoginForm;