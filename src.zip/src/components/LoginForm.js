import React from 'react';
// Update the path if necessary

function LoginForm({ onLogin }) {
  const handleLogin = () => {
    // Add your login logic here
    // After successful login, call the onLogin function
    onLogin();
  };

  return (
    <div className="login-form">
      
      <h2>Login</h2>
      <input type="text" placeholder="Username" />
      <input type="password" placeholder="Password" />
      <button onClick={handleLogin}>Login</button><br />
       
    </div>
  );
}

export default LoginForm;
