// src/HomePage.js
import React from 'react';

const HomePage = () => {
  return <div>Home Page Content</div>;
};

export default HomePage;
