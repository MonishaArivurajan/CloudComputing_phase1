// src/HomePage.js
import React from 'react';
const HomePage = ({ employeeName }) => {
  return(
  <div> 
  <h1>WELCOME {employeeName} <span role="img" aria-label="smile">😊</span></h1>
  <div>hello da!</div>
  </div>
);
};
export default HomePage;