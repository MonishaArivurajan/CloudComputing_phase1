import React, {useState, useEffect } from 'react';
import axios from 'axios';

const Dashboard = ({ onSelectEmployee }) => {
  const [employees, setEmployees] = useState([]);
  useEffect(() => {
    // Fetch the employee list from the API
    axios.get('http://127.0.0.1:8000/api/employee-details/')
      .then(response => {
        console.log('Employee data:', response.data); // Check the data
        setEmployees(response.data);
      })
      .catch(error => {
        console.error('There was an error fetching the employee list!', error);
      });
  }, []);
  return (
    <div>
      <h1>Employee Dashboard</h1>
      <ul>
        {employees.map(employee => (
          <li
            key={employee.emp_id} // Use emp_id as the key
            onClick={() => onSelectEmployee(employee.emp_id)}
          >
            {employee.employee_name}
          </li>
        ))}
      </ul>
    </div>
  );
};
export default Dashboard;
