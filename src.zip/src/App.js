import React, { useState } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import CalendarTable from './components/CalendarTable';
import HomePage from './components/HomePage';
import TeamTable from './components/TeamTable';
import EmployeeList from './components/EmployeeList';
import EmployeeDetail from './components/EmployeeDetail';
import LoginForm from './components/LoginForm'; // Import the LoginForm component
import './App.css';

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  const handleLogin = () => {
    setIsLoggedIn(true);
    navigate('/home');
  };

  const handleCalendarClick = () => {
    setIsLoggedIn(true);
    navigate('/calendar');
  };

  const handleSelectEmployee = (employeeId) => {
    navigate(`/employees/${employeeId}`);
  };

  if (!isLoggedIn) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="app">
      <Navbar />
      <div className="main-content-container">
        <Sidebar onCalendarClick={handleCalendarClick} />
        <div className="main-content">
          <Routes>
            <Route path="/home" element={<HomePage />} />
            <Route path="/calendar" element={<CalendarTable />} />
            <Route path="/employees" element={<EmployeeList onSelectEmployee={handleSelectEmployee} />} />
            <Route path="/employees/:id" element={<EmployeeDetail />} />
            <Route path="/teamtable" element={<TeamTable />} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default App;
