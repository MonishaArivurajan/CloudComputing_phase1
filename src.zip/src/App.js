// src/App.js
import React, { useState, useEffect } from 'react';
import { Routes, Route, useNavigate } from 'react-router-dom';
import axios from 'axios';
import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import CalendarTable from './components/CalendarTable';
import HomePage from './components/HomePage';
import  TeamTable from './components/Teamtable'
import EmployeeList from './components/EmployeeList';
import EmployeeDetail from './components/EmployeeDetail';
import LoginForm from './components/LoginForm'; // Import the LoginForm component
import './App.css';
const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [empid, setEmpid] = useState(null);
  const [employeeName, setEmployeeName] = useState('');
  const navigate = useNavigate();

  const handleLogin = (empid) => {
    setEmpid(empid);
    setIsLoggedIn(true);
    navigate('/home');
  };

  useEffect(() => {
    if (empid) {
      axios.get(`http://127.0.0.1:8000/api/employee-details/${empid}/`)
        .then(response => {
          setEmployeeName(response.data.employee_name);
        })
        .catch(error => {
          console.error('There was an error fetching the employee details!', error);
        });
    }
  }, [empid]);

  const handleCalendarClick = () => {
    navigate('/calendar');
  };

  const handleSelectEmployee = (employeeId) => {
    navigate(`/employees/${employeeId}`);
  };

  const handleStatusChange = (status) => {
    console.log(`Status changed to: ${status}`);
  };

  if (!isLoggedIn) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div className="app">
      <Navbar />
      <div className="main-content-container">
        <Sidebar onCalendarClick={handleCalendarClick} />
        <div className="main-content">
          <Routes>
            <Route path="/home" element={<HomePage employeeName={employeeName} />} />
            <Route path="/calendar" element={<CalendarTable empid={empid} employeeName={employeeName} />} />
            <Route path="/employees" element={<EmployeeList onSelectEmployee={handleSelectEmployee} />} />
            <Route path="/employees/:id" element={<EmployeeDetail />} />
            <Route path="/teamtable" element={<TeamTable />} />
            <Route path="/employee/:id" element={<EmployeeDetail onStatusChange={handleStatusChange} />} />
          </Routes>
        </div>
      </div>
    </div>
  );
};

export default App;
