from rest_framework import status, viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.generics import CreateAPIView
from rest_framework.views import APIView
from django.http import JsonResponse
from django.views.decorators.http import require_GET
from .models import MyUser, EmployeeDetail, TimeSheet,ManagerSheet,TeamleaderSheet
from .serializers import *
from rest_framework.permissions import AllowAny
from rest_framework import generics


class RegisterView(CreateAPIView):
    queryset = MyUser.objects.all()
    serializer_class = RegisterSerializer
    

class LoginView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        userid = serializer.validated_data['userid']
        password = serializer.validated_data['password']
        print("Test: ",userid,password)

        user = MyUser.objects.filter(userid=userid, password=password).first()
        print(user)

        if user is not None:
            personstatus = getattr(user, 'personstatus', None)
            print(personstatus)
            response_data = {
                'userid': userid,
                'personstatus': personstatus
            }
            if personstatus == 'Employee':
                response_data['redirect_url'] = '/employee-dashboard/'
            elif personstatus == 'Lead':
                response_data['redirect_url'] = '/lead-dashboard/'
            elif personstatus == 'Manager':
                response_data['redirect_url'] = '/manager-dashboard/'
            elif personstatus == 'HR':
                response_data['redirect_url'] = '/hr/'
            else:
                return Response({'error': 'Unknown person status'}, status=status.HTTP_400_BAD_REQUEST)

            return Response(response_data, status=status.HTTP_200_OK)
        else:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)

        # Fallback response to ensure every code path returns a Response
        return Response({'error': 'An unexpected error occurred'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
class ChangePasswordView(APIView):
    def post(self, request):
        userid = request.data.get('userid')
        old_password = request.data.get('old_password')
        new_password = request.data.get('new_password')

        user = MyUser.objects.filter(userid=userid).first()
        if user and user.check_password(old_password):
            user.set_password(new_password)
            user.save()
            return Response({'status': 'password changed'}, status=status.HTTP_200_OK)
        return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)




class EmployeeDetailView(APIView):
    def get(self, request):
        print('pass')
        employee_id = request.query_params.get('employee_id')
        print(employee_id)
        if employee_id:
            try:
                employee = MyUser.objects.get(userid=employee_id)
                employee_details = EmployeeDetail.objects.filter(employee=employee).first()
                if employee_details:
                    serializer = EmployeeDetailSerializer(employee_details)
                    return Response(serializer.data, status=status.HTTP_200_OK)
                return Response({'error': 'Employee detail not found'}, status=status.HTTP_404_NOT_FOUND)
            except MyUser.DoesNotExist:
                return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
        else:
            employees = MyUser.objects.all()
            serializer = MyUserSerializer(employees, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)

    def post(self, request):
        print('here')
        serializer = EmployeeDetailSerializer(data=request.data)
        print(request.data)
        print(serializer.is_valid())
        if serializer.is_valid():
            try:
                employee = MyUser.objects.get(userid=request.data['employee'])
                project_name = ManagerSheet.objects.get(project_name=request.data['project_name'])
                module_name = TeamleaderSheet.objects.get(module_name=request.data['module_name'])
                serializer.save(employee=employee, project_name=project_name, module_name=module_name)
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            except (MyUser.DoesNotExist, ManagerSheet.DoesNotExist, TeamleaderSheet.DoesNotExist):
                return Response({'error': 'Data not found'}, status=status.HTTP_400_BAD_REQUEST)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
class TimeSheetViewSet(viewsets.ModelViewSet):
    queryset = TimeSheet.objects.all()
    serializer_class = TimeSheetSerializer

    # @action(detail=False, methods=['post'])
    # def add(self, request):
    #     data = request.data
    #     print("Received data:", data)
        
    #     employee_id = data.get('id')
    #     project_name = data.get('project_name')  # Retrieve project_name from request data
    #     module_name = data.get('module_name')  
         
    #     try:
    #         employee = MyUser.objects.get(userid=employee_id)
    #         print('pass')
    #     except MyUser.DoesNotExist:
    #         return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
        
    #     # Modify the data to include the employee ID directly
    #     data['employee'] = employee.id
    #     data['manager_approval'] = 'Pending'
    #     data['project_name'] =ManagerSheet.objects.get(project_name = project_name)
    #     data['module_name'] = TeamleaderSheet.objects.get(module_name = module_name)
    #     print("Data after adding employee:", data)
        
    #     print('updated :',data)
    #     serializer = self.get_serializer(data=data)
    #     print("Serializer valid:", serializer.is_valid())
        
    #     if serializer.is_valid():
    #         serializer.save()
    #         return Response(serializer.data, status=status.HTTP_201_CREATED)
        
    #     print("Serializer errors:", serializer.errors)
    #     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    @action(detail=False, methods=['post'])
    def add(self, request):
        data = request.data
        print("Received data:", data)
        
        employee_id = data.get('id')
        project_name_id = data.get('project_name')  # Expecting primary key
        module_name_id = data.get('module_name')    # Expecting primary key
        print(module_name_id)
        
        try:
            print('pass1')
            employee = MyUser.objects.get(userid=employee_id)
            print('pass2')
            project = ManagerSheet.objects.get(project_name=project_name_id)
            print('pass3')
            module = TeamleaderSheet.objects.get(module_name=module_name_id)
            print(module)
        except (MyUser.DoesNotExist, ManagerSheet.DoesNotExist, TeamleaderSheet.DoesNotExist):
            return Response({'error': 'Data not found'}, status=status.HTTP_400_BAD_REQUEST)
        
        # data['employee'] = int(employee.userid)
        # data['id'] = int(data['id'])
        # # data['id'] = int(data['id'])  # Ensure ID is an integer
        # data['week'] = data.get('week') # Convert week to integer
        # data['total'] = int(data.get('total'))  # Convert total to integer
        # data['tue'] = int(data.get('tue') ) # Convert to integer
        # data['wed'] = int(data.get('wed'))  # Convert to integer
        # data['thu'] = int(data.get('thu') ) # Convert to integer
        # data['fri'] = int(data.get('fri') ) # Convert to integer
        # data['mon'] = int(data.get('mon') ) # Convert to integer
        # data['manager_approval'] = 'Pending'
        # data['project_name'] = project.project_name
        # data['module_name'] = module.module_name
        # data['leave_days'] = 0
        # data.pop('id')
        # data.pop('team_name')



        data1 = {
            "project_name": project.project_name,
            "module_name": module.id,
            "employee": employee.id,
            "week": data.get('week'),
            "mon": int(data.get('mon') ),
            "tue": int(data.get('tue') ),
            "wed": int(data.get('wed') ),
            "thu": int(data.get('thu') ),
            "fri": int(data.get('fri') ),
            "total": int(data.get('total') ),
            "leave_days": 0,
            "lead_approval": 'Pending',
            "manager_approval": 'Pending'
        }
        print('updated',data1,'\n\n\n')
        serializer = self.get_serializer(data=data1)
        print(serializer.is_valid)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
    
    
    
    @action(detail=False, methods=['get'])
    def user_timesheets(self, request):
        print(request.data)
        user_id = request.query_params.get('user_id')
        print('User ID:', user_id)  # Log user_id to check if it is being retrieved correctly
        
        if user_id:
            timesheets = TimeSheet.objects.filter(employee__userid=user_id)
        else:
            timesheets = TimeSheet.objects.all()

        serializer = self.get_serializer(timesheets, many=True)
        return Response(serializer.data)


class ManagerSheetViewSet(viewsets.ModelViewSet):
    queryset = ManagerSheet.objects.all()
    serializer_class = ManagerSheetSerializer
    permission_classes = [AllowAny]

class TeamleaderSheetViewSet(viewsets.ModelViewSet):
    queryset = TeamleaderSheet.objects.all()
    serializer_class = TeamleaderSheetSerializer
    def post(self, request, *args, **kwargs):
        serializer = TeamleaderSheetSerializer(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response({'message': 'Teamleader sheet added successfully.'}, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
class CalculateSalaryView(APIView):
        def get(self, request, user_id):
            try:
                user = MyUser.objects.get(userid=user_id)
            except MyUser.DoesNotExist:
                return Response({'error': 'User not found'}, status=status.HTTP_404_NOT_FOUND)
        
        # Fetch the user's timesheets
            timesheets = TimeSheet.objects.filter(employee=user)

            total_salary = 0
            leave_days=0
            for timesheet in timesheets:
            # Calculate the salary based on the working hours and leave days
                total_hours = timesheet.mon + timesheet.tue + timesheet.wed + timesheet.thu + timesheet.fri
                hourly_rate = 250  # Example hourly rate
                salary = (total_hours - (timesheet.leave_days * 8)) * hourly_rate
            
            # Update the salary field in the timesheet
                timesheet.salary = salary
                timesheet.save()
            
            # Add to the total salary for the user
                total_salary += salary

            return Response({'user_id': user_id, 'total_salary': total_salary , 'total_working_hours':total_hours ,'Leave_days':leave_days}, status=status.HTTP_200_OK)
