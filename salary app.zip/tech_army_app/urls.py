from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import RegisterView, LoginView, ChangePasswordView, EmployeeDetailView, TimeSheetViewSet, ManagerSheetViewSet, TeamleaderSheetViewSet, CalculateSalaryView


router = DefaultRouter()
router.register(r'timesheet', TimeSheetViewSet)
router.register(r'manager', ManagerSheetViewSet)
router.register(r'teamleader', TeamleaderSheetViewSet)


urlpatterns = [
    path('register/', RegisterView.as_view(), name='register'),
    path('login/', LoginView.as_view(), name='login'),
    path('change-password/', ChangePasswordView.as_view(), name='change-password'),
    path('employee/', EmployeeDetailView.as_view(), name='employee-detail'),
    path('calculate-salary/<str:user_id>/', CalculateSalaryView.as_view(), name='calculate-salary'),
    path('', include(router.urls)),  # This includes the router-generated URLs
]
