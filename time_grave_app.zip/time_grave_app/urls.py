# myapp/urls.py
from django.urls import path
from .views import LoginView, RegisterView, EmployeeDetailViewSet  # Update import for EmployeeDetailViewSet

urlpatterns = [
    path('login/', LoginView.as_view(), name='login'),
    path('register/', RegisterView.as_view(), name='register'),
    path('employee-details/', EmployeeDetailViewSet.as_view({'get': 'list'}), name='employee-list'),
    path('employee-details/<int:emp_id>/', EmployeeDetailViewSet.as_view({'get': 'retrieve'}), name='employee-detail'),
    path('employee-details/<int:pk>/update_approval/', EmployeeDetailViewSet.as_view({'post': 'update_approval'}), name='update-approval'),
    path('employee-details/<int:pk>/reject/', EmployeeDetailViewSet.as_view({'post': 'reject'}), name='reject'),
]
