# myapp/views.py
from django.http import JsonResponse
from django.shortcuts import render
from django.contrib.auth import login as auth_login, logout as auth_logout, authenticate
from django.views.decorators.csrf import csrf_exempt
from rest_framework import status, generics, viewsets
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes, action
from rest_framework.permissions import AllowAny
from .models import User, EmployeeDetail
from .serializers import RegisterSerializer, EmployeeDetailSerializer, LoginSerializer

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = (AllowAny,)
    serializer_class = RegisterSerializer

    def create(self, request, *args, **kwargs):
        serializer = self.get_serializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response({"message": "You have successfully registered"}, status=status.HTTP_201_CREATED)

class LoginView(generics.CreateAPIView):
    permission_classes = (AllowAny,)
    serializer_class = LoginSerializer

    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        emp_id = serializer.validated_data['emp_id']
        password = serializer.validated_data['password']

        user = User.objects.get(emp_id=emp_id)
        if user.check_password(password):
            position = user.position
            if position == 'employee':
                return Response({'redirect_url': '/employee-dashboard/'}, status=status.HTTP_200_OK)
            elif position == 'lead':
                return Response({'redirect_url': '/lead-dashboard/'}, status=status.HTTP_200_OK)
            elif position == 'manager':
                return Response({'redirect_url': '/home/'}, status=status.HTTP_200_OK)
            else:
                return Response({'error': 'Unknown person status'}, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response({'error': 'Invalid credentials'}, status=status.HTTP_400_BAD_REQUEST)

class EmployeeDetailView(generics.ListCreateAPIView):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer
    permission_classes = (AllowAny,)

class EmployeeDetailByEmpIDView(generics.RetrieveAPIView):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer
    permission_classes = (AllowAny,)
    lookup_field = 'emp_id'

class EmployeeListView(generics.ListAPIView):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer

def get_employee_details(request):
    employees = list(EmployeeDetail.objects.values(
        'emp_id',
        'employee_name',
        'start_time',
        'end_time',
        'project_name',
        'lead_approval'
    ))
    return JsonResponse(employees, safe=False)

class EmployeeDetailViewSet(viewsets.ModelViewSet):
    queryset = EmployeeDetail.objects.all()
    serializer_class = EmployeeDetailSerializer

    @action(detail=True, methods=['post'])
    def update_approval(self, request, pk=None):
        employee = self.get_object()
        employee.lead_approval = 'Approved'
        employee.save()
        return Response({'status': 'Timesheet approved by Lead'}, status=status.HTTP_200_OK)

    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        employee = self.get_object()
        employee.lead_approval = 'Rejected'
        employee.save()
        return Response({'status': 'Timesheet rejected by Lead'}, status=status.HTTP_200_OK)
