from django.apps import AppConfig


class TimeGraveAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'time_grave_app'
