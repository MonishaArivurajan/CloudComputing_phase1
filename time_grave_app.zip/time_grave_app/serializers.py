# myapp/serializers.py

from rest_framework import serializers
from .models import User, EmployeeDetail
from django.contrib.auth.password_validation import validate_password

class RegisterSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True, required=True, validators=[validate_password])
    joining_date = serializers.DateField()

    class Meta:
        model = User
        fields = ('username', 'email', 'emp_id', 'position', 'joining_date', 'password')

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            emp_id=validated_data['emp_id'],
            position=validated_data['position'],
            joining_date=validated_data['joining_date'],
            password=validated_data['password']
        )
        return user

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['username', 'email', 'emp_id', 'position', 'joining_date']
        extra_kwargs = {
            'password': {'write_only': True},
            'Time_stamp': {'read_only': True},
            'joining_date': {'read_only': True}
        }

    def create(self, validated_data):
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            emp_id=validated_data['emp_id'],
            position=validated_data['position'],
            password=validated_data['password']
        )
        return user

class EmployeeDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = EmployeeDetail
        fields = '__all__'

class LoginSerializer(serializers.Serializer):
    emp_id = serializers.CharField()
    password = serializers.CharField(write_only=True)